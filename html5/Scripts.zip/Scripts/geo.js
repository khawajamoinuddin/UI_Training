function geoFindMe() {

    var output = document.getElementById("out");

  if (!navigator.geolocation){
    output.innerHTML = "<p>Geolocation is not supported by your browser</p>";
    return;
  }

  function success(position) {
    var latitude  = position.coords.latitude;
    var longitude = position.coords.longitude;

    output.innerHTML = '<p>Latitude is ' + latitude + '° <br>Longitude is ' + longitude + '°</p>';

//    Displaying the result in a map  
    
    var img = new Image();
    img.src = "https://maps.googleapis.com/maps/api/staticmap?center=" + latitude + "," + longitude + "&zoom=16&size=300x300&sensor=false";

    output.appendChild(img);
      
  };

  function error() {
    output.innerHTML = "Unable to retrieve your location";
  };

    /*function error(error){
        switch(error.code){
                case error.PERMISSION_DENIED:
                    x.innerHTML="User denied the request for Geolocation";
                    break;
                case error.POSITION_UNAVAILABLE:
                    x.innerHTML="Location information is unavailable";
                    break;
                case error.TIMEOUT:
                    x.innerHTML="The request to get the user location timed out";
                    break;
                case error.UNKNOWN_ERROR:
                    x.innerHTML="An unknown error occured";
                    break;
            }
      };*/

  output.innerHTML = "<p>Locating…</p>";

  navigator.geolocation.getCurrentPosition(success, error);
}