var person = function(firstName, lastName){
    this.firstName=firstName;
    this.lastName=lastName;
}

function logPerson(){
    var fasi = new person('Fasi','Rehan');
    console.log(fasi);
}
logPerson();


/*function logPerson(person){
    console.log(person);
}
var fasi = new person('fasi','rehan');


logPerson(fasi);*/
    
