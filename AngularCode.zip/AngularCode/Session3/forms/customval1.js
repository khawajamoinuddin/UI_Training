var myApp = angular.module("myApp",[]);
var INTEGER_REGEXP = /^\-?\d+$/;
myApp.directive('integer',function(){
    return{
        require:'ngModel',
        link:fuction(scope,elem,attr,ctrl){
            ctrl.$validators.integer=function(modelValue, viewValue){
                if(ctrl.$isEmpty(modelValue)){
                //consider empty models to be valid
                return true;
                }
                if(INTEGER_REGEXP.test(viewValue)){
                    //it is valid
                    return true;
                }
                //it is invalid
                return false;
            };
        }
    };
});

app.directive('username',function($q, $timeout){
    return{
        require:"ngModel";
        link:function(scope,elem,attr,ctrl){
            var usernames=['Rahul','Rohit','Raina','Ravindra'];
            ctrl.$asyncValidators.username=function(modelValue,viewValue){
                if(ctrl.$isEmpty(modelValue)){
                //consider empty model value
                return $q.when();
                }
                var def=$q.defer();
            $timeout(fuction(){
                //mark as delayed response
                if(usernames.indexOf(modelValue)==-1){
                //the username is available
                def.resolve();
                }else{
                def.reject();
                }
            },2000);
            return def.promise;
            };
        }
    };
});