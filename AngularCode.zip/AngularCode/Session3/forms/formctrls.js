var app = angular.module("myApp",[]);
app.controller("formCtrl",function($scope){
$scope.master={firstname:"Khaja", lastname:"Moinuddin"};
$scope.reset = function(){
    $scope.user=angular.copy($scope.master);
};
$scope.reset();
});