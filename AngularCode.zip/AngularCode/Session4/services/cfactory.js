var myApp = angular.module("myApp",[]);
myApp.factory('random',function(){
    var randomObject={};
    var num=Math.floor(Math.random()*10);
    randomObject.generate = function(){
        return num;
    };
    return randomObject;
});
myApp.controller("mainController",function($scope, random){
   $scope.generateRandom = function(){
        $scope.randomNumber = random.generate();
   };
});
