var myApp = angular.module("myApp",[]);
myApp.service("fromService",function(){
    this.message="This is from service";
});

myApp.factory("fromFactory",function(){
    var factory={};
    factory.message="This is from factory";
    return factory;
});

myApp.provider("fromProvider",function(){
    var m1="This is from provider";
    return{
        $get:function(){
            return{
                message:m1
            }
        }
    }
});
myApp.controller("mainController",function($scope,fromService,fromFactory,fromProvider){
    $scope.greetMessage=[fromService.message, fromFactory.message, fromProvider.message];
    
});