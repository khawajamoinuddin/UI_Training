var app = angular.module("myApp",[]);

//define a provider using provider() function
app.provider('configurable', function () {
 var name = '';
 this.setName = function (newName) {
 name = newName;
 };
 this.$get = function () {
 return name;
 };
});
 
//configuring provider using config() function
app.config(function (configurableProvider) {
 configurableProvider.setName('Khaja Moinuddin');
});

 app.controller("myController", ['$scope','configurable',function ($scope, configurable) {
     
  $scope.providerName = configurable;
     
 }]);