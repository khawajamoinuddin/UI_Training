var myApp = angular.module("myApp",[]);
myApp.controller("mainController",function($scope, $log, $filter){
    /*console.log($scope);
    console.log($log);*/
    
    $log.log($scope);
    $log.log($log);
    
    $log.log("Hello");
    $log.info("This is some info");
    $log.warn("Warning!");
    $log.debug("Some debug information");
    $log.error("This is an error");
    
    $scope.name="Moin";
    $scope.formattedname=$filter('uppercase')($scope.name);
    $log.info($scope.name);
    $log.info($scope.formattedname);
    
});