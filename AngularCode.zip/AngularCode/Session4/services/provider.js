var myApp = angular.module("myApp",[]);
myApp.provider('date',function(){
    return{
        $get:function(){
            return{
                showDate:function(){
                    var date = new Date();
                    return date.getHours();
                }
            }
        }
    }
});

myApp.controller("mainController",function($scope,date){
    $scope.greetMessage = date.showDate();
});