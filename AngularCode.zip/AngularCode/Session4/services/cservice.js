var myApp = angular.module("myApp",[]);
myApp.service('random',function(){
    var num=Math.floor(Math.random()*10);
    this.generate = function(){
        return num;
    }
});
myApp.controller("mainController",function($scope, random){
    $scope.generateRandom = function(){
        $scope.randomNumber = random.generate();
    }
});
