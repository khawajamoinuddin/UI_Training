var app = angular.module("myApp",['ngRoute']);
app.config(function($routeProvider){
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html',
        controller:'homeController'
    })
    .when('/blog',{
        templateUrl:'pages/blog.html',
        controller:'blogController'
    })
    .when('/about',{
        templateUrl:'pages/about.html',
        controller:'aboutController'
    })  
    .otherwise( {
        redirectTo:'/'
    });
    
});

app.controller("homeController",function($scope){
    $scope.message="Hello from Home Controller";
});
app.controller("blogController",function($scope){
    $scope.message="Hello from Blog Controller";
});
app.controller("aboutController",function($scope){
    $scope.message="Hello from About Controller";
});
