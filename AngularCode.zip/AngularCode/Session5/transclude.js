var myApp = angular.module('myApp',[]);

function MyCtrl($scope) {
    $scope.log=[];   
}

myApp.directive('myDirective', function(){
	return{
  	restrict:'A',
		transclude: false,
    template: '<div class="something" ng-transclude > This is my new content</div>'
	}
});
