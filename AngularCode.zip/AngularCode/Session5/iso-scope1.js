var myApp = angular.module("myApp",[]);
myApp.controller("mainController",function($scope){
$scope.xyz = {
        name: "xyz",
        address:"abids, hyd"
        };
$scope.abc = {
        name: "abc",
        address:"koti, hyd"
        };

})
.directive("myCustomer",function(){
    return{
        restrict:'E',
        scope:{
            customerInfo:'=info'
        },
        templateUrl:'my-customer.html'
    };
});