

myApp.directive("hello",function(){
    return{
        restrict:'EA',
      
        template:'<div>Hello Everyone</div>'
    };
        
});
