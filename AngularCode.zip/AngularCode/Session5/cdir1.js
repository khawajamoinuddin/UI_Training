var myApp = angular.module("myApp",[]);

myApp.directive("hello",function(){
    return{
        
        restrict:'E',
      
        /*template:'<div>Hello Everyone</div>'*/
        
       /* template:'<div>Hello Everyone <span ng-transclude></span></div>',
       transclude:true*/
              
       /* replace:true,*/
        
        /*templateUrl:'helloTemplate.html'*/
    };
});
myApp.controller("mainController",function($scope){
    
});
