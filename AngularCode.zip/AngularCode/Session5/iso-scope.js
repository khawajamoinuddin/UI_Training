var myApp = angular.module("myApp",[]);
myApp.controller("xyzCtrl",function($scope){
$scope.customer = {
        name: "xyz",
        address:"abids, hyd"
        };
})
.controller("abcCtrl",function($scope){
$scope.customer = {
        name: "abc",
        address:"koti, hyd"
        };
})
.directive("myCustomer",function(){
    return{
        restrict:'E',
        templateUrl:'my-customer.html'
    };
});