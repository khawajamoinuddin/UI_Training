var myApp = angular.module("myApp",[]);
myApp.directive('student',function(){
    return{
        restrict:'E',
        template:"Student: <b>{{student.name}}</b>, Roll No: <b>{{student.rno}}</b>",
        scope: {
        student:"=name"
        },
        compile: function(elements,attributes){
            elements.css("border","3px solid red")
        
        var linkFunction = function($scope, element, attributes){
            element.html("Student: <b>" + $scope.student.name+ "</b>,Roll No: <b>" 
                          + $scope.student.rno +"</b></b>");
            element.css("background-color","#ee00ee");
        }
        return linkFunction;
        }
    };
})
.controller("studentController",function($scope){
    $scope.sachin = {
        name:"Sachin Tendulkar",
        rno:"001"
    };
    $scope.sharukh = {
        name:"Sharukh Khan",
        rno:"007"
    };
});
