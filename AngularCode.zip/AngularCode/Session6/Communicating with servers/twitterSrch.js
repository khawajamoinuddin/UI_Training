var myApp = angular.module("Twitter",['ngResource']);
myApp.controller("twitterCtrl",function($scope, $resource){
    $scope.twitter = $resource("http://search.twitter.com/:action",
                              { action: 'search.json', q:'angular.js', callback:'JSON_CALLBACK' },
                              { get: {method: 'JSONP'}}
                              );
    $scope.twitterResult=$scope.twitter.get();
});