var myApp =  angular
.module("myApp",[])
.controller("mainController",function($scope){
var emp = [
{name: "Dravid", dob: new Date("January 10, 1972"), gender:"Male", salary: 255000},
{name: "Sania", dob: new Date("September 15, 1982"), gender:"Female", salary: 305000},
{name: "Sharukh", dob: new Date("February 02, 1962"), gender:"Male", salary: 855000},
{name: "Sachin", dob: new Date("December 25, 1975"), gender:"Male", salary: 555000},
{name: "Nehwal", dob: new Date("March 11, 1986"), gender:"Female", salary: 155000}
];

$scope.empl = emp;
$scope.sortColumn="name";
});


    
            