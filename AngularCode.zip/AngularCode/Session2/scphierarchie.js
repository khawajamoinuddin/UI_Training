var myApp = angular.module("myApp",[]);
myApp.controller("greetController",['$scope','$rootScope',function($scope,$rootScope){
    $scope.name="World";
    $rootScope.department="Angular";
}])
.controller("listController",['$scope',function($scope){
    $scope.names=['rohit','rahane','rahul'];
}]);