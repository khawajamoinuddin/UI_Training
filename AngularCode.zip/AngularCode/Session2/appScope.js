var myApp = angular.module('myApp',[]);
myApp.controller('mainController', function($scope){
    $scope.username="rahul";
    $scope.sayHello=function(){
        $scope.greeting='Hello '+$scope.username+'!';
    }
});