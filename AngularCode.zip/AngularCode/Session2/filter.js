var myApp=angular.module("myApp",[]);
myApp.controller('filterController',['filterFilter',function(filterFilter){
    this.array=[
        {name:"Shikhar"},
        {name:"Rohit"},
        {name:"Virat"},
        {name:"Rahane"},
        {name:"Raina"},
        {name:"Dhoni"},
        {name:"Jadeja"},
        {name:"Ashwin"},
        {name:"Shami"},
        {name:"Umesh"},
        {name:"Ishant"},
        
    ];
    this.filteredArray=filterFilter(this.array,'a');
}]);