var myApp = angular.module("myApp",[]);
myApp.controller("eventController",['$scope',function($scope){
    $scope.count=0;
    $scope.$on('myEvent',function(){
        $scope.count++;
    });
}]);