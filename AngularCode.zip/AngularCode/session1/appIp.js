var appIp = angular.module("appIp",[]);
appIp.controller("mainController",function($scope){
    $scope.name="Fouzan";
});