var myApp = angular.module("myModule",[]);
myApp.controller("myController",function($scope){
    $scope.message="You are learning AngularJS";
});

/*
myApp.directive("directiveName",fuction(){

});

myApp.service("serviceName",function(){

});

*/


