var myApp = angular.module("myApp",[]);
myApp.controller("mainController",function($scope){
    $scope.firstName = 'Fahad';
    $scope.lastName = 'Rayan';
    $scope.fullName = function(){
        return ($scope.firstName + " " + $scope.lastName);
    };
});
