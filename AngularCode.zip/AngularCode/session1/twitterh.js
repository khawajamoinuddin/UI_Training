var myApp = angular.module("myApp",[]);
myApp.controller("mainController",function($scope,$filter ){
    $scope.handle="";
    
    console.log($scope.handle);
    
    $scope.lowercasehandle = function(){
        return $filter('lowercase')($scope.handle);
    };
});